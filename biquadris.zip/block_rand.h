#ifndef BLOCK_RAND_H
#define BLOCK_RAND_H
#include "block.h"

class BlockRand: public Block{
    public:
        BlockRand(int levelSpawned, int weight);
};

#endif

#ifndef BLOCK_DOUGHNUT_H
#define BLOCK_DOUGHNUT_H
#include "block.h"

class BlockDoughnut: public Block{
    public:
        BlockDoughnut(int levelSpawned, int weight);
};

#endif

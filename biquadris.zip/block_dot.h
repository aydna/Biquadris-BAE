#ifndef BLOCK_DOT_H
#define BLOCK_DOT_H
#include "block.h"

class BlockDot: public Block{
    public:
        BlockDot(int levelSpawned, int weight);
};

#endif

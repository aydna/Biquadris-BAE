#ifndef BLOCK_X_H
#define BLOCK_X_H
#include "block.h"

class BlockX: public Block{
    public:
        BlockX(int levelSpawned, int weight);
};

#endif

#ifndef BLOCK_J_H
#define BLOCK_J_H
#include "block.h"

class BlockJ: public Block{
    public:
        BlockJ(int levelSpawned, int weight);
};

#endif

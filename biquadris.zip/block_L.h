#ifndef BLOCK_L_H
#define BLOCK_L_H
#include "block.h"

class BlockL: public Block{
    public:
        BlockL(int levelSpawned, int weight);
};

#endif

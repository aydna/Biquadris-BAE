#ifndef BLOCK_Z_H
#define BLOCK_Z_H
#include "block.h"

class BlockZ: public Block{
    public:
        BlockZ(int levelSpawned, int weight);
};

#endif

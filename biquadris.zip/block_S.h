#ifndef BLOCK_S_H
#define BLOCK_S_H
#include "block.h"

class BlockS: public Block{
    public:
        BlockS(int levelSpawned, int weight);
};

#endif

#ifndef BLOCK_I_H
#define BLOCK_I_H
#include "block.h"

class BlockI: public Block{
    public:
        BlockI(int levelSpawned, int weight);
};

#endif

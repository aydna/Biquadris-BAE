#ifndef BLOCK_T_H
#define BLOCK_T_H
#include "block.h"

class BlockT: public Block{
    public:
        BlockT(int levelSpawned, int weight);
};

#endif

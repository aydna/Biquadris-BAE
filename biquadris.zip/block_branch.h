#ifndef BLOCK_BRANCH_H
#define BLOCK_BRANCH_H
#include "block.h"

class BlockBranch: public Block{
    public:
        BlockBranch(int levelSpawned, int weight);
};

#endif

#ifndef BLOCK_O_H
#define BLOCK_O_H
#include "block.h"

class BlockO: public Block{
    public:
        BlockO(int levelSpawned, int weight);
};

#endif
